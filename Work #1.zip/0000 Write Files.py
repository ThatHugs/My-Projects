activeFile=open("0000 Writen File.txt","r")
active=activeFile.read()
(name,password,phrase,isTrue)=(input(),input(),"",0)
openFile=open("0000 Users.txt","r")
FILE=openFile.read()
(alphabet,userInputFile,compilePE)=("-_1= a+[2]Z{3}b;4'Y#5:c@6~X,7.\nd/8<W>9?e|0VeUgThSiRjQkPlOmNnMoLpKqJrIsHtGuFvEw)D(*x&C^y%B$z£A!",FILE,"")
for letterUIF in userInputFile:
    numberUIF=alphabet.index(letterUIF)-1
    if numberUIF < 0:
        numberUIF+=97
    compilePE+=alphabet[numberUIF]
file=compilePE
compilePE=""
for letterI in file:
    if letterI == "*":
        compilePE+=" "
    else:
        compilePE+=letterI
    File=compilePE
for letter in File:
    if isTrue==1:
        if phrase==password:
            isTrue=2
    elif phrase==name:
        isTrue=1
    if isTrue==2 and letter == "\n":
        userCode=phrase
        isTrue=3
        break
    elif letter==" "or letter=="\n":
        phrase=""
    else:
        phrase+=letter
if isTrue==3:
    (alphabet,inputPhrase,compilePostEncryption)=("-_1= a+[2]Z{3}b;4'Y#5:c@6~X,7.\nd/8<W>9?e|0VeUgThSiRjQkPlOmNnMoLpKqJrIsHtGuFvEw)D(*x&C^y%B$z£A!",active,"")
    for letterFIP in inputPhrase:
        numberFL=alphabet.index(letterFIP)+1
        if numberFL > 97:
            numberFL-=97
        compilePostEncryption+=alphabet[numberFL]
    with open(userCode+" "+(input()+".txt"),"w") as file:
        file.write(compilePostEncryption)
activeFile.close
openFile.close
input()
