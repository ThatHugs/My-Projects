(name,password,phrase,isTrue)=(input(),input(),"",0)
openFile=open("0000 Users.txt","r")
FILE=openFile.read()
(alphabet,userInputFile,compilePE)=("-_1= a+[2]Z{3}b;4'Y#5:c@6~X,7.\nd/8<W>9?e|0VeUgThSiRjQkPlOmNnMoLpKqJrIsHtGuFvEw)D(*x&C^y%B$z£A!",FILE,"")
for letterUIF in userInputFile:
    numberUIF=alphabet.index(letterUIF)-1
    if numberUIF < 0:
        numberUIF+=97
    compilePE+=alphabet[numberUIF]
file=compilePE
compilePE=""
for letterI in file:
    if letterI == "*":
        compilePE+=" "
    else:
        compilePE+=letterI
    File=compilePE
for letter in File:
    if isTrue==1:
        if phrase==password:
            isTrue=2
    elif phrase==name:
        isTrue=1
    if isTrue==2 and letter == "\n":
        userCode=phrase
        isTrue=3
        break
    elif letter==" "or letter=="\n":
        phrase=""
    else:
        phrase+=letter
if isTrue==3:
    fileName=input()
    openFile=open(userCode+" "+fileName+".txt","r")
    file=openFile.read()
    openFile.close
    (alphabet,inputPhrase,compilePostEncryption)=("-_1= a+[2]Z{3}b;4'Y#5:c@6~X,7.\nd/8<W>9?e|0VeUgThSiRjQkPlOmNnMoLpKqJrIsHtGuFvEw)D(*x&C^y%B$z£A!",file,"")
    for letterFIP in inputPhrase:
        numberFL=alphabet.index(letterFIP)-1
        if numberFL < 0:
            numberFL+=97
        compilePostEncryption+=alphabet[numberFL]
    file=compilePostEncryption
    compilePostEncryption=""
    for letter in file:
        if letter == "*":
            compilePostEncryption+=" "
        else:
            compilePostEncryption+=letter
    print(compilePostEncryption)
input()
